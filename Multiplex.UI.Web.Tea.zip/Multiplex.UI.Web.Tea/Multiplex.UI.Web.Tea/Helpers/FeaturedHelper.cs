﻿using Multiplex.Models.Tea;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Multiplex.UI.Web.Tea.Helpers
{
    public static class FeaturedHelper
    {
        public static BusinessProfile BusinessProfile{ get; set; }

        public static DateTime Date { get; set; }
    }
}