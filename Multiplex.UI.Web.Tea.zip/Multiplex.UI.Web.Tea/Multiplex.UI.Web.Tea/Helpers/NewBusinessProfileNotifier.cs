﻿using Multiplex.DomainServices.Security;
using Multiplex.DomainServices.Tea;
using Multiplex.Models.Tea;
using Multiplex.Repositories.Tea;
using Multiplex.Utilities.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Multiplex.UI.Web.Tea.Helpers
{
    public class NewBusinessProfileNotifier
    {
        public NewBusinessProfileNotifier(BusinessProfile businessProfile, UserInformation loggedInUserInformation)
        {
            BusinessProfile = businessProfile;
            LoggedInUserInformation = loggedInUserInformation;
        }

        private BusinessProfile BusinessProfile { get; set; }

        public UserInformation LoggedInUserInformation { get; set; }

        public void Notify()
        {
            var service = new DomainService<BusinessProfile>();
            var securityService = new DomainService();
            var communicationService = new DomainServices.Communication.DomainService();
            var smsService = ConfigurationReader.GetAppSetting(Multiplex.Models.Security.Constants.SMS_SERVICE);
            var loggedInUserName = BusinessProfile.UserInformationId == LoggedInUserInformation.Id ? "yourself" : LoggedInUserInformation.FirstName;
            var loggedInUserSurname = BusinessProfile.UserInformationId == LoggedInUserInformation.Id ? string.Empty : LoggedInUserInformation.Surname;
            var from = ConfigurationReader.GetAppSetting("NewBusinessProfileEmailFrom");
            var subject = string.Format(ConfigurationReader.GetAppSetting("NewBusinessProfileEmailSubject"), BusinessProfile.Name);
            var body = string.Format(ConfigurationReader.GetAppSetting("NewBusinessProfileEmailBody"), BusinessProfile.UserInformation.FirstName, BusinessProfile.UserInformation.Surname, BusinessProfile.Name, loggedInUserName, loggedInUserSurname, ConfigurationReader.GetAppSetting("Domain"), BusinessProfile.Id, "<br/>");
            var smsBody = string.Format(ConfigurationReader.GetAppSetting("NewBusinessProfileEmailBody"), BusinessProfile.UserInformation.FirstName, BusinessProfile.UserInformation.Surname, BusinessProfile.Name, loggedInUserName, loggedInUserSurname, ConfigurationReader.GetAppSetting("Domain"), BusinessProfile.Id, " \r\n");
            var emailTemplatePath = string.Format("{0}App_Data\\EmailTemplates.xml", HttpContext.Current.Request.PhysicalApplicationPath);
            var emailTemplate = communicationService.GetTemplate(emailTemplatePath, "GeneralTemplate");
            var newBody = string.Format(emailTemplate.Body, body, emailTemplate.Client, emailTemplate.From);
            var status = communicationService.SendMail(string.Empty, from, BusinessProfile.UserInformation.Email, string.Empty, string.Empty, subject, newBody, string.Empty);

            if (!string.IsNullOrWhiteSpace(smsService))
            {
                var smsHelper = new SmsHelper(BusinessProfile.UserInformation, smsBody);
                smsHelper.SendRecommendationSms();
            }
        }
    }
}