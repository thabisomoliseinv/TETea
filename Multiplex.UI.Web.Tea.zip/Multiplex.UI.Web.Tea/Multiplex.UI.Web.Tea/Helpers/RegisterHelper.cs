﻿using Multiplex.DomainServices.Security;
using Multiplex.Models.Tea;
using Multiplex.Repositories.Tea;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Multiplex.UI.Web.Tea.Helpers
{
    public class RegisterHelper
    {
        public RegisterHelper(Guid userId, UserInformation userInformation)
        {
            UserId = userId;
            UserInformation = userInformation;
        }

        private Guid UserId { get; set; }

        private UserInformation UserInformation { get; set; }

        public Tuple<bool,string> Response { get; set; }

        public void Register()
        {
            UserInformation.Error = string.Empty;
            UserInformation.UserName = UserInformation.Cellphone;

            var userManager = new UserManager();
            string[] roles = null;

            if (UserInformation.DateOfBirth.AddYears(13) < DateTime.Now)
            {
                roles = new string[] { Multiplex.Models.Tea.Constants.CLIENT };
            }

            //((UserInfo)userInformation).Cellphone = userInformation.Cellphone;
            Response = userManager.Register<TeaDataContext, UserInformation>(UserInformation, UserId, true, roles);
        }
    }
}