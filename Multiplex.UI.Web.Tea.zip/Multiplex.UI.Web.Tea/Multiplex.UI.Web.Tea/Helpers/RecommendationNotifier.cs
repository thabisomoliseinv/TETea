﻿using Multiplex.DomainServices.Security;
using Multiplex.DomainServices.Tea;
using Multiplex.Models.Tea;
using Multiplex.Repositories.Tea;
using Multiplex.Utilities.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Multiplex.UI.Web.Tea.Helpers
{
    public class RecommendationNotifier
    {
        public RecommendationNotifier(BusinessProfileRecommendation businessProfileRecommendation)
        {
            BusinessProfileRecommendation = businessProfileRecommendation;
        }

        private BusinessProfileRecommendation BusinessProfileRecommendation { get; set; }

        public void Notify()
        {
            var service = new DomainService<BusinessProfile>();
            var securityService = new DomainService();
            var communicationService = new DomainServices.Communication.DomainService();
            var smsService = ConfigurationReader.GetAppSetting(Multiplex.Models.Security.Constants.SMS_SERVICE);
            var businessProfile = service.GetEntity(c => c.Id == BusinessProfileRecommendation.BusinessProfileId && c.Active, new string[] { /*"UserInformation",*/ "Category", "BusinessProfileRecommendations", "BusinessProfileRecommendations.UserInformation" });
            
            if (businessProfile != null)
            {
                businessProfile.UserInformation = securityService.GetEntity<TeaDataContext, UserInformation>(businessProfile.UserInformationId);
            }

            var recommenderName = businessProfile.UserInformationId == BusinessProfileRecommendation.UserInformationId ? "yourself" : BusinessProfileRecommendation.UserInformation.FirstName;
            var recommenderSurname = businessProfile.UserInformationId == BusinessProfileRecommendation.UserInformationId ? string.Empty : BusinessProfileRecommendation.UserInformation.Surname;

            var from = ConfigurationReader.GetAppSetting("RecommendationEmailFrom");
            var subject = string.Format(ConfigurationReader.GetAppSetting("RecommendationEmailSubject"), businessProfile.Name);
            var body = string.Format(ConfigurationReader.GetAppSetting("RecommendationEmailBody"), businessProfile.UserInformation.FirstName, businessProfile.UserInformation.Surname, businessProfile.Name, recommenderName, recommenderSurname, ConfigurationReader.GetAppSetting("Domain"), BusinessProfileRecommendation.Id, "<br/>");
            var smsBody = string.Format(ConfigurationReader.GetAppSetting("RecommendationEmailBody"), businessProfile.UserInformation.FirstName, businessProfile.UserInformation.Surname, businessProfile.Name, recommenderName, recommenderSurname, ConfigurationReader.GetAppSetting("Domain"), BusinessProfileRecommendation.Id, " \r\n");
            var emailTemplatePath = string.Format("{0}App_Data\\EmailTemplates.xml", HttpContext.Current.Request.PhysicalApplicationPath);
            var emailTemplate = communicationService.GetTemplate(emailTemplatePath, "GeneralTemplate");
            var newBody = string.Format(emailTemplate.Body, body, emailTemplate.Client, emailTemplate.From);
            var status = communicationService.SendMail(string.Empty, from, businessProfile.UserInformation.Email, string.Empty, string.Empty, subject, newBody, string.Empty);

            if (!string.IsNullOrWhiteSpace(smsService))
            {
                var smsHelper = new SmsHelper(businessProfile.UserInformation, smsBody);
                smsHelper.SendRecommendationSms();
            }
        }
    }
}