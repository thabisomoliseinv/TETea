﻿using Multiplex.Models.Tea;
using Multiplex.Repositories.Tea;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multiplex.UI.Web.Tea.Helpers
{
    public class UserHelper
    {
        public static string GetFullName(Guid userId)
        {
            var result = string.Empty;
            var securityService = new DomainServices.Security.DomainService();
            var user = securityService.GetEntity<TeaDataContext, UserInformation>(userId, null);

            if (user != null)
            {
                result = string.Format("{0} {1}",user.FirstName, user.Surname);
            }

            return result;
        }

        public static string GetFullName(string userName)
        {
            var result = string.Empty;
            var securityService = new DomainServices.Security.DomainService();
            var user = securityService.GetEntity<TeaDataContext, UserInformation>(userName, null);

            if (user != null)
            {
                result = string.Format("{0} {1}",user.FirstName, user.Surname);
            }

            return result;
        }
    }
}
