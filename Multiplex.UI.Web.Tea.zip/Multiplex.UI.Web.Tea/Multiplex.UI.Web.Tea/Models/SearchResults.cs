﻿using Multiplex.Models.Tea;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace Multiplex.UI.Web.Tea.Models
{
    public class SearchResults
    {
        public SearchResults(int resultsFound, IEnumerable<IGrouping<string, BusinessProfile>> businessProfiles, int categoryId, string searchText)
        {
            ResultsFound = string.Format("{0} business profile(s) found.", resultsFound );
            BusinessProfiles = businessProfiles;
            CategoryId = categoryId;
            SearchText = searchText;
        }
        public string ResultsFound { get; private set; }

        public IEnumerable<IGrouping<string, BusinessProfile>> BusinessProfiles { get; private set; }

        [DisplayName("Category")]
        public int CategoryId { get; private set; }

        [DisplayName("Search Text")]
        public string SearchText { get; private set; }
    }
}