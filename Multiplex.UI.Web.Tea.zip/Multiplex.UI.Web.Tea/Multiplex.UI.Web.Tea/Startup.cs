﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Multiplex.UI.Web.Tea.Startup))]
namespace Multiplex.UI.Web.Tea
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
