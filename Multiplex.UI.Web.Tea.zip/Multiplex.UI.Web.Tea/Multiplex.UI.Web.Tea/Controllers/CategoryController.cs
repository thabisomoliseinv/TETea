﻿using Multiplex.DomainServices.Security;
using Multiplex.DomainServices.Tea;
using Multiplex.Models.Tea;
using Multiplex.Repositories.Tea;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Multiplex.UI.Web.Tea.Controllers
{
    [Authorize(Roles = Multiplex.Models.Tea.Constants.ROLE_ADMIN)]
    public class CategoryController : BaseController
    {
        public ActionResult Index()
        {
            var service = new DomainService<Category>();
            var categories = service.GetEntities(c => c.Id > 0, null);
            return View(categories);
        }

        public ActionResult SaveCategory(int categoryId = -1)
        {
            var service = new DomainService<Category>();
            var category = service.GetEntity(c => c.Id == categoryId, null);

            if (category == null)
            {
                category = new Category();
            }

            return View(category);
        }

        [HttpPost]
        public ActionResult SaveCategory(Category category)
        {
            category.Error = string.Empty;
            var service = new DomainService<Category>();
            var existingCategory = service.GetEntity(c => c.Name == category.Name || c.DisplayName == category.DisplayName, null);

            if ((existingCategory != null && category.Id < 1) || (existingCategory != null && category.Id != existingCategory.Id))
            {
                category.Error = "Category already exist.";
                return View(category);
            }

            category = service.SaveEntity(category, UserId, null);

            if (category != null && category.Id > 0)
            {
                return RedirectToAction("Index", "Category");
            }

            category.Error = "Category not created successfully.";
            return View(category);
        }

        [AllowAnonymous]
        public ActionResult GetCategoryBusinessProfiles(int categoryId)
        {
            var service = new DomainService<Category>();
            var businessProfileNeedService = new DomainService<BusinessProfileNeed>();
            var category = service.GetEntity(c => c.Id == categoryId, new string[] { "BusinessProfiles", "BusinessProfiles.BusinessProfileLikes" });
            var securityService = new DomainService();

            List<BusinessProfileNeed> businessProfileNeeds = null;
            BusinessProfile featuredBusinessProfile = null;

            if (category != null && category.BusinessProfiles != null)
            {
                featuredBusinessProfile = category.BusinessProfiles.OrderBy(bp => bp.Id).First();

                var businessProfilesWithLikes = category.BusinessProfiles.Where(bp => bp.BusinessProfileLikes != null && bp.BusinessProfileLikes.Count > 0).ToList();

                if (businessProfilesWithLikes != null && businessProfilesWithLikes.Count > 0)
                {
                    featuredBusinessProfile = businessProfilesWithLikes.OrderByDescending(bp => bp.BusinessProfileLikes.Count).First();
                }

                featuredBusinessProfile.UserInformation = securityService.GetEntity<TeaDataContext, UserInformation>(featuredBusinessProfile.UserInformationId);
                businessProfileNeeds = businessProfileNeedService.GetEntities(bpn => bpn.CategoryId == category.Id, new string[] { "BusinessProfile" });
            }

            return View(new Tuple<Category, BusinessProfile, List<BusinessProfileNeed>>(category, featuredBusinessProfile, businessProfileNeeds));
        }

    }
}