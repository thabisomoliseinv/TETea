﻿using Multiplex.DomainServices.Tea;
using Multiplex.Models.Tea;
using Multiplex.UI.Web.Tea.Helpers;
using Multiplex.Utilities.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Multiplex.UI.Web.Tea.Controllers
{
    public class CommunicationController : BaseController
    {
        [Authorize]
        public ActionResult ViewCommunication(int id)
        {
            var service = new DomainService<Communication>();
            var communication = service.GetEntity(c => c.Id == id, new string[] { "CommunicationType" });
            return View(communication);
        }

        [Authorize(Roles = Multiplex.Models.Tea.Constants.CLIENT)]
        public ActionResult CreateCommunication(int businessProfileId)
        {
            var communication = new Communication();
            communication.BusinessProfileId = businessProfileId;
            return View(communication);
        }

        [HttpPost]
        [Authorize(Roles = Multiplex.Models.Tea.Constants.CLIENT)]
        public ActionResult CreateCommunication(Communication communication)
        {
            var service = new DomainService<Communication>();
            var fileProcessingService = new Multiplex.DomainServices.FileProcessing.DomainService();
            var files = fileProcessingService.ProcessFiles(Request.Files);

            if (files != null && files.Count > 0)
            {
                var file = files.First();

                communication.Document = file.Value;
                communication.DocumentName = file.Key;
            }

            communication = service.SaveEntity(communication, UserId, new string[] { "CommunicationType", "BusinessProfile", "BusinessProfile.UserInformation" });
            var communicationNotifier = new CommunicationNotifier(communication);
            communicationNotifier.Notify();
            communication.Error = string.Format("{0} saved successfully.", communication.CommunicationType.DisplayName);
            return View(communication);
        }

        [Authorize]
        public ActionResult GetImage(int communicationId)
        {
            var service = new DomainService<Communication>();
            var communication = service.GetEntity(c => c.Id == communicationId, null);

            if (communication != null && communication.Document != null && communication.Document.Length > 0)
            {
                return File(communication.Document, "image/png");
            }

            var path = string.Format("{0}{1}", Request.PhysicalApplicationPath, ConfigurationReader.GetAppSetting("DefaultImage"));
            return File(path, "image/png");
        }

        [Authorize]
        public ActionResult Unsubscribe(int businessProfileId)
        {
            var service = new DomainService<BusinessProfileLike>();
            var businessProfileLike = service.GetEntity(c => c.BusinessProfileId == businessProfileId && c.UserInformationId == UserInformation.Id, null);
            var outcome = "Unsubscription failed.";

            if (businessProfileLike != null)
            {
                businessProfileLike.Active = false;
                businessProfileLike = service.SaveEntity(businessProfileLike, UserId, new string[] { "BusinessProfile" });
                outcome = string.Format("Successfully unsubcribed for notifications from {0}", businessProfileLike.BusinessProfile.Name);
            }

            return View((object)outcome);
        }
    }
}