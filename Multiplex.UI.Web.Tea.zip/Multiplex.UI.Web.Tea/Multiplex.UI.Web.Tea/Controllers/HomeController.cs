﻿using Multiplex.DomainServices.Tea;
using Multiplex.Models.Tea;
using Multiplex.UI.Web.Tea.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Multiplex.UI.Web.Tea.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            var service = new DomainService<BusinessProfile>();
            var businessProfiles = service.GetEntities(c => c.Id > 0, new string[] { "Category", "Category.BusinessProfileNeeds" });
            var a = businessProfiles.GroupBy(bp => bp.Category).OrderByDescending(c => c.Key.BusinessProfiles.Count).Select(bp => bp.Key);
            
            //return RedirectToAction("FeaturedBusiness", "BusinessProfile");
            var searchResults = new SearchResults(0, null, 0, string.Empty);
            return View( new Tuple<List<Category>, SearchResults>(a.ToList(), searchResults));
        }
    }
}