﻿using Multiplex.DomainServices.Tea;
using Multiplex.Models.Tea;
using Multiplex.UI.Web.Tea.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Multiplex.UI.Web.Tea.Controllers
{
    public class SearchController : Controller
    {
        public ActionResult Index()
        {
            IEnumerable<IGrouping<string, BusinessProfile>> groupedProfiles = null;
            var searchResult = new SearchResults(0, groupedProfiles, 0, string.Empty);
            return View(searchResult);
        }

        [HttpPost]
        public ActionResult Index(FormCollection collection)
        {
            var searchResult = GetSearchResults(collection);

            return View(searchResult);
        }

        public ActionResult Location()
        {
            IEnumerable<IGrouping<string, BusinessProfile>> groupedProfiles = null;
            var searchResult = new SearchResults(0, groupedProfiles, 0, string.Empty);
            return View(searchResult);
        }

        [HttpPost]
        public ActionResult Location(FormCollection collection)
        {
            var searchResult = GetSearchResults(collection);

            return View(searchResult);
        }

        private SearchResults GetSearchResults(FormCollection collection)
        {
            int categoryId = 0;
            string searchText = collection["searchText"].ToLower();
            int resultsFound = 0;

            if (collection["categoryId"] != null)
            {
                int.TryParse(collection["categoryId"].ToString(), out categoryId);
            }

            var service = new DomainService<BusinessProfile>();
            IEnumerable<IGrouping<string, BusinessProfile>> groupedProfiles = null;
            var businessProfiles = service.GetEntities(bp => bp.Active && (
                  (bp.CategoryId == categoryId && !string.IsNullOrWhiteSpace(searchText) && (bp.Name.ToLower().Contains(searchText) || bp.Services.ToLower().Contains(searchText) || bp.ResidentialAddress.ToLower().Contains(searchText))) ||
                  (bp.CategoryId == categoryId && string.IsNullOrWhiteSpace(searchText)) ||
                  (categoryId == 0 && string.IsNullOrWhiteSpace(searchText)) ||
                  (categoryId == 0 && !string.IsNullOrWhiteSpace(searchText) && (bp.Name.ToLower().Contains(searchText) || bp.Services.ToLower().Contains(searchText) || bp.ResidentialAddress.ToLower().Contains(searchText)))
                ), new string[] { "Category" });

            if (businessProfiles != null)
            {
                resultsFound = businessProfiles.Count;
                groupedProfiles = businessProfiles.GroupBy(bp => bp.Category.DisplayName);
            }

            var results = new SearchResults(resultsFound, groupedProfiles, categoryId, searchText);

            return results;
        }
    }
}