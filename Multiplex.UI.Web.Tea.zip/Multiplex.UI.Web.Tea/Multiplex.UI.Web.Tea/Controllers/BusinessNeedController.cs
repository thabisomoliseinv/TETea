﻿using Multiplex.DomainServices.Tea;
using Multiplex.Models.Tea;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Multiplex.UI.Web.Tea.Controllers
{
    public class BusinessNeedController : BaseController
    {

        [Authorize(Roles = Multiplex.Models.Tea.Constants.CLIENT)]
        public ActionResult CreateBusinessNeed(int businessProfileId)
        {
            var businessProfileNeed = new BusinessProfileNeed();
            businessProfileNeed.BusinessProfileId = businessProfileId;
            return View(businessProfileNeed);
        }

        [HttpPost]
        [Authorize(Roles = Multiplex.Models.Tea.Constants.CLIENT)]
        public ActionResult CreateBusinessNeed(BusinessProfileNeed businessProfileNeed)
        {
            var service = new DomainService<BusinessProfileNeed>();
            
            businessProfileNeed = service.SaveEntity(businessProfileNeed, UserId, null);
            businessProfileNeed.Error = "Business Need saved successfully.";

            return View(businessProfileNeed);
        }
    }
}