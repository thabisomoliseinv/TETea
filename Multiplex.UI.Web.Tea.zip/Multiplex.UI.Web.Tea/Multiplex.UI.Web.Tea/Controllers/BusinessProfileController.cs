﻿using Multiplex.DomainServices.Security;
using Multiplex.DomainServices.Tea;
using Multiplex.Models.Tea;
using Multiplex.Repositories.Tea;
using Multiplex.UI.Web.Tea.Helpers;
using Multiplex.UI.Web.Tea.Models;
using Multiplex.Utilities.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Multiplex.UI.Web.Tea.Controllers
{
    [Authorize]
    public class BusinessProfileController : BaseController
    {
        // GET: BusinessProfile
        [Authorize(Roles = Multiplex.Models.Tea.Constants.CLIENT)]
        public ActionResult Index()
        {
            var businessProfile = new BusinessProfile();
            businessProfile.UserInformationId = UserInformation.Id;
            businessProfile.Cellphone = UserInformation.Cellphone;
            ViewBag.title = "Create my Business";
            return View(businessProfile);
        }

        [Authorize(Roles = Multiplex.Models.Tea.Constants.ROLE_ADMIN)]
        public ActionResult UserIndex(string cellphone)
        {
            var businessProfile = new BusinessProfile();
            businessProfile.UserInformationId = UserInformation.Id;
            businessProfile.Cellphone = cellphone;
            ViewBag.title = "Create for existing client";

            return View("Index", businessProfile);
        }

        [Authorize(Roles = Multiplex.Models.Tea.Constants.ROLE_ADMIN)]
        public ActionResult NewUserIndex()
        {
            var businessProfile = new BusinessProfile();
            businessProfile.UserInformation = new UserInformation();
            return View("NewUserIndex", businessProfile);
        }

        [HttpPost]
        [Authorize(Roles = Multiplex.Models.Tea.Constants.CLIENT)]
        public ActionResult NewUserIndex(BusinessProfile businessProfile)
        {
            if ((DateTime.Today - businessProfile.UserInformation.DateOfBirth).Days / 365.25 < 13)
            {
                businessProfile.Error = "You have to be 13 years and older to register.";
                return View(businessProfile);
            }

            var registerHelper = new RegisterHelper(UserId, businessProfile.UserInformation);
            registerHelper.Register();

            if (!registerHelper.Response.Item1)
            {
                businessProfile.UserInformation.Error = registerHelper.Response.Item2;
                businessProfile.Error = registerHelper.Response.Item2;
                return View(businessProfile);
            }

            businessProfile.Cellphone = businessProfile.UserInformation.Cellphone;

            businessProfile = CreateBusinessProfile(businessProfile);

            return View(businessProfile);
        }

        [Authorize(Roles = Multiplex.Models.Tea.Constants.CLIENT)]
        public ActionResult SaveBusinessProfile(int businessProfileId)
        {
            var service = new DomainService<BusinessProfile>();
            var businessProfile = service.GetEntity(c => c.Id == businessProfileId, new string[] { "UserInformation", "Category", "BusinessProfileRecommendations" });

            if (businessProfile == null)
            {
                businessProfile = new BusinessProfile();
            }
            else
            {
                businessProfile.Cellphone = businessProfile.UserInformation.Cellphone;
            }

            return View(businessProfile);
        }

        [HttpPost]
        [Authorize(Roles = Multiplex.Models.Tea.Constants.CLIENT)]
        public ActionResult SaveBusinessProfile( BusinessProfile businessProfile)
        {
            businessProfile.Error = string.Empty;
            var service = new DomainService<BusinessProfile>();
            var securityService = new DomainService();
            var business = service.GetEntity(c => c.Name == businessProfile.Name, null);

            if ((business != null && businessProfile.Id < 1) || (business != null && businessProfile.Id != business.Id))
            {
                businessProfile.Error = "Business Profile already exist.";
                return View(businessProfile);
            }

            var fileProcessingService = new Multiplex.DomainServices.FileProcessing.DomainService();
            var files = fileProcessingService.ProcessFiles(Request.Files);

            if (files != null && files.Count > 0)
            {
                var file = files.First();

                if (!string.IsNullOrWhiteSpace(file.Key) && file.Value != null && file.Value.Length > 0)
                {
                    businessProfile.Logo = file.Value;
                    businessProfile.LogoFileName = file.Key;
                }
            }

            if (!string.IsNullOrWhiteSpace(businessProfile.LogoFileName) && businessProfile.Logo == null)
            {
                var logoBusinessProfile = service.GetEntity(c => c.Id == businessProfile.Id, null);

                if (logoBusinessProfile != null && logoBusinessProfile.Logo != null && logoBusinessProfile.Logo.Length > 0)
                {
                    businessProfile.Logo = logoBusinessProfile.Logo;
                }
            }

            businessProfile = service.SaveEntity(businessProfile, UserId, new string[] { /*"UserInformation",*/ "Category", "BusinessProfileRecommendations" });

            if (businessProfile != null)
            {
                businessProfile.UserInformation = securityService.GetEntity<TeaDataContext, UserInformation>(businessProfile.UserInformationId);
            }

            if (FeaturedHelper.BusinessProfile != null && FeaturedHelper.BusinessProfile.Id == businessProfile.Id)
            {
                FeaturedHelper.BusinessProfile = businessProfile;
            }

            businessProfile.Error = "Business Profile updated successfully.";
            return View(businessProfile);
        }

        [AllowAnonymous]
        public ActionResult View(int businessProfileId)
        {
            var service = new DomainService<BusinessProfile>();
            var securityService = new DomainService();
            var businessProfile = service.GetEntity(c => c.Id == businessProfileId && c.Active, new string[] { /*"UserInformation",*/ "Category", "BusinessProfileRecommendations", "BusinessProfileRecommendations.UserInformation", "BusinessProfileRecommendations.CommentConversations.UserInformation", "BusinessProfileLikes", "BusinessProfileLikes.UserInformation", "BusinessProfileImages" });
            if (businessProfile != null)
            {
                businessProfile.UserInformation = securityService.GetEntity<TeaDataContext, UserInformation>(businessProfile.UserInformationId);

                if (businessProfile.UserInformation != null)
                {
                    businessProfile.Cellphone = businessProfile.UserInformation.Cellphone;
                }
            }

            if (UserInformation != null)
            {
                ViewBag.UserInformationId = UserInformation.Id;
            }

            return View("View", businessProfile);
        }

        [HttpPost]
        [Authorize]
        public ActionResult Index(BusinessProfile businessProfile)
        {
            businessProfile = CreateBusinessProfile(businessProfile);
            return View(businessProfile);
        }

        private BusinessProfile CreateBusinessProfile(BusinessProfile businessProfile)
        {
            businessProfile.Error = string.Empty;
            var service = new DomainService<BusinessProfile>();
            var securityService = new DomainService();
            var existingBusinessProfile = service.GetEntity(c => c.Name == businessProfile.Name, null);

            if (existingBusinessProfile != null)
            {
                businessProfile.Error = "Business Profile already exist.";
                return businessProfile;
            }

            if (businessProfile.Cellphone != UserInformation.Cellphone)
            {
                var userService = new DomainService<UserInformation>();
                var userInformation = userService.GetEntity(u => u.Cellphone == businessProfile.Cellphone, null);

                if (userInformation == null)
                {
                    businessProfile.Error = string.Format("User with cellphone: {0} not found", businessProfile.Cellphone);
                    return businessProfile;
                }

                businessProfile.UserInformationId = userInformation.Id;
                businessProfile.UserInformation = null;
            }

            var fileProcessingService = new Multiplex.DomainServices.FileProcessing.DomainService();
            var files = fileProcessingService.ProcessFiles(Request.Files);

            if (files != null || files.Count > 0)
            {
                var file = files.First();

                businessProfile.Logo = file.Value;
                businessProfile.LogoFileName = file.Key;
            }

            businessProfile = service.SaveEntity(businessProfile as BusinessProfile, UserId, new string[] { /*"UserInformation",*/ "Category", "BusinessProfileRecommendations" });

            if (businessProfile != null && businessProfile.Id > 0)
            {
                businessProfile.UserInformation = securityService.GetEntity<TeaDataContext, UserInformation>(businessProfile.UserInformationId);
                businessProfile.Cellphone = businessProfile.UserInformation.Cellphone;
                businessProfile.Error = "Business Profile created successfully.";

                if (businessProfile.ModifiedById != null && businessProfile.ModifiedById != Guid.Empty)
                {
                    businessProfile.Error = "Business Profile updated successfully.";
                }
                else
                {
                    var newBusinessNotifier = new NewBusinessProfileNotifier(businessProfile, UserInformation);
                    newBusinessNotifier.Notify();
                }

                return businessProfile;
            }

            businessProfile.Error = "Business Profile not created successfully.";
            return businessProfile;
        }

        [Authorize]
        [Authorize(Roles = Multiplex.Models.Tea.Constants.ROLE_ADMIN)]
        public ActionResult MyBusinesses()
        {
            var service = new DomainService<BusinessProfile>();
            IEnumerable<IGrouping<string, BusinessProfile>> groupedProfiles = null;
            var businessProfiles = service.GetEntities(c => c.UserInformationId == UserInformation.Id, new string[] { "Category", "UserInformation" });

            if (businessProfiles != null)
            {
                businessProfiles = businessProfiles.OrderBy(bp => bp.Name).ToList();
                groupedProfiles = businessProfiles.GroupBy(bp => bp.Category.DisplayName);
            }

            ViewBag.UserInformationId = UserInformation.Id;
            return View(groupedProfiles);
        }

        [Authorize(Roles = Multiplex.Models.Tea.Constants.ROLE_ADMIN)]
        public ActionResult ClientBusinesses(int userInformationId)
        {
            var service = new DomainService<BusinessProfile>();
            IEnumerable<IGrouping<string, BusinessProfile>> groupedProfiles = null;
            var businessProfiles = service.GetEntities(c => c.UserInformationId == userInformationId, new string[] { "Category", "UserInformation" });

            if (businessProfiles != null)
            {
                businessProfiles = businessProfiles.OrderBy(bp => bp.Name).ToList();
                groupedProfiles = businessProfiles.GroupBy(bp => bp.Category.DisplayName);
            }

            ViewBag.UserInformationId = UserInformation.Id;
            return View(groupedProfiles);
        }

        [AllowAnonymous]
        public ActionResult GetImage(int businessProfileId)
        {
            var service = new DomainService<BusinessProfile>();
            var businessProfile = service.GetEntity(c => c.Id == businessProfileId, null);

            if (businessProfile != null && businessProfile.Logo != null && businessProfile.Logo.Length > 0)
            {
                return File(businessProfile.Logo, "image/png");
            }

            var path = string.Format("{0}{1}", Request.PhysicalApplicationPath, ConfigurationReader.GetAppSetting("DefaultImage"));
            return File(path, "image/png");
        }

        [Authorize]
        [HttpPost]
        public ActionResult Activation(int businessProfileId)
        {
            var service = new DomainService<BusinessProfile>();
            var businessProfile = service.GetEntity(bp => bp.Id == businessProfileId && (bp.UserInformationId == UserInformation.Id || (bp.AllowAdminEdit && User.IsInRole(Multiplex.Models.Tea.Constants.ROLE_ADMIN))), new string[] { "UserInformation" });

            if (businessProfile != null)
            {
                businessProfile.Cellphone = businessProfile.UserInformation.Cellphone;
                businessProfile.Active = businessProfile.Active ? false : true;
                service.SaveEntity(businessProfile, UserId, null);

                if (FeaturedHelper.BusinessProfile != null && FeaturedHelper.BusinessProfile.Id == businessProfileId && businessProfile.Active)
                {
                    FeaturedHelper.BusinessProfile = null;
                }
            }

            var result = businessProfile.Active ? "Deactivate" : "Activate";

            return Json(result, JsonRequestBehavior.AllowGet);
        }

        [Authorize]
        [HttpPost]
        public ActionResult Delete(int businessProfileId)
        {
            var service = new DomainService<BusinessProfile>();
            var result = false;

            new DomainService<BusinessProfileRecommendation>().DeleteEntities(bpr => bpr.BusinessProfileId == businessProfileId);
            new DomainService<BusinessProfileImage>().DeleteEntities(bpr => bpr.BusinessProfileId == businessProfileId);
            var needs = new DomainService<BusinessProfileNeed>().GetEntities(bpr => bpr.BusinessProfileId == businessProfileId || bpr.FulfillerBusinessProfileId == businessProfileId, null);

            new DomainService<BusinessProfileNeed>().DeleteEntities(bpr => bpr.BusinessProfileId == businessProfileId || bpr.FulfillerBusinessProfileId == businessProfileId);
            new DomainService<BusinessProfileLike>().DeleteEntities(bpr => bpr.BusinessProfileId == businessProfileId);

            result = service.DeleteEntity(businessProfileId);

            if (FeaturedHelper.BusinessProfile != null && FeaturedHelper.BusinessProfile.Id == businessProfileId)
            {
                FeaturedHelper.BusinessProfile = null;
            }

            return Json(result, JsonRequestBehavior.AllowGet);
        }

        [AllowAnonymous]
        public ActionResult FeaturedBusiness()
        {
            var service = new DomainService<BusinessProfile>();
            var securityService = new DomainService();
            var businessProfile = FeaturedHelper.BusinessProfile;
            if ((DateTime.Now - FeaturedHelper.Date).Hours >= 24 || businessProfile == null)
            {
                var ids = service.GetEntities(bp => bp.Active, null).Select(bp => bp.Id);

                if (ids != null && ids.Count() > 0)
                {
                    var randomId = new Random().Next(ids.Count() - 1);
                    var id = ids.ElementAt(randomId);
                    businessProfile = service.GetEntity(bp => bp.Active && bp.Id == id, new string[] { /*"UserInformation",*/ "Category", "BusinessProfileRecommendations", "BusinessProfileRecommendations.UserInformation", "BusinessProfileLikes", "BusinessProfileLikes.UserInformation" });

                    if (businessProfile != null)
                    {
                        businessProfile.UserInformation = securityService.GetEntity<TeaDataContext, UserInformation>(businessProfile.UserInformationId);

                        if (businessProfile.UserInformation != null)
                        {
                            businessProfile.Cellphone = businessProfile.UserInformation.Cellphone;
                        }
                    }
                    FeaturedHelper.BusinessProfile = businessProfile;
                    var userInformation = securityService.GetEntity<TeaDataContext, UserInformation>(User.Identity.Name, null);
                    FeaturedHelper.Date = DateTime.Now;
                }
            }

            if (UserInformation != null)
            {
                ViewBag.UserInformationId = UserInformation.Id;
            }

            return View("FeaturedBusiness", businessProfile);
        }

        [HttpPost]
        [Authorize(Roles = Multiplex.Models.Tea.Constants.CLIENT)]
        public ActionResult BusinessImages(FormCollection formCollection)
        {
            var businessProfileId = 0;
            var aBusinessProfileId = formCollection["BusinessProfileId"];
            var service = new DomainService<BusinessProfileImage>();
            var securityService = new DomainService();
            var fileProcessingService = new Multiplex.DomainServices.FileProcessing.DomainService();
            var files = fileProcessingService.ProcessFiles(Request.Files);

            if (files != null && files.Count > 0 && aBusinessProfileId != null && int.TryParse(aBusinessProfileId, out businessProfileId))
            {
                foreach (var file in files)
                {
                    if (!string.IsNullOrWhiteSpace(file.Key) && file.Value != null && file.Value.Length > 0)
                    {
                        var businessProfileImage = new BusinessProfileImage() { BusinessProfileId = businessProfileId };
                        businessProfileImage.Image = file.Value;
                        businessProfileImage.ImageFileName = file.Key;

                        service.SaveEntity(businessProfileImage, UserId, null);
                    }
                }
            }


            return RedirectToAction("SaveBusinessProfile", new { businessProfileId = businessProfileId });
        }
    }
}