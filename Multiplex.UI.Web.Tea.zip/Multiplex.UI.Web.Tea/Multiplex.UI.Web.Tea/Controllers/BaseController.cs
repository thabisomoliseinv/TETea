﻿using Multiplex.DomainServices.Security;
using Multiplex.Models.Tea;
using Multiplex.Repositories.Tea;
using System;
using System.Collections.Generic;
using System.Web.Mvc;

namespace Multiplex.UI.Web.Tea.Controllers
{
	public class BaseController: Controller
	{
		private Guid userId = Guid.Empty;
		private UserInformation userInformation = null;

		public Guid UserId
		{
			get
			{
				if(userId == null || userId == Guid.Empty)
				{
					var securityService = new DomainService();
					var userInformation = securityService.GetEntity<TeaDataContext, UserInformation>(User.Identity.Name, null);

					if(userInformation != null)
					{
						userId = userInformation.UserId;
					}
				}

				return userId;
			}
		}

		public UserInformation UserInformation
		{
			get
			{
				if(userInformation == null)
				{
					var securityService = new DomainService();

					userInformation = securityService.GetEntity<TeaDataContext, UserInformation>(UserId, null);
				}

				return userInformation;
			}
		}

		public Dictionary<string, string> ConvertFormCollection()
		{
			var result = new Dictionary<string, string>();

			foreach(var key in Request.Form.AllKeys)
			{
				result.Add(key, Request.Form[key]);
			}

			return result;
		}
	}
}