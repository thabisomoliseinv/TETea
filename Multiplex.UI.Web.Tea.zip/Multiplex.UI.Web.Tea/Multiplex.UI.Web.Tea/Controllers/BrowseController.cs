﻿using Multiplex.DomainServices.Tea;
using Multiplex.Models.Tea;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Multiplex.UI.Web.Tea.Controllers
{
    public class BrowseController : BaseController
    {
        // GET: Browse
        public ActionResult Index()
        {
            var service = new DomainService<BusinessProfile>();
            IEnumerable<IGrouping<string, BusinessProfile>> groupedProfiles = null;
            var businessProfiles = service.GetEntities(bp => bp.Active, new string[]{"Category"});

            if (businessProfiles != null)
            {
                businessProfiles = businessProfiles.OrderBy(bp => bp.Name).ToList();
                groupedProfiles = businessProfiles.GroupBy(bp => bp.Category.DisplayName);
            }

            if (UserInformation != null)
            {
                ViewBag.UserInformationId = UserInformation.Id;
            }

            return View(groupedProfiles);
        }
    }
}