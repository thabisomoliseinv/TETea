﻿using System;
using System.Globalization;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using Multiplex.UI.Web.Tea.Models;
using Multiplex.Models.Tea;
using Multiplex.DomainServices.Security;
using Multiplex.Repositories.Tea;
using System.Web.Security;
using System.Collections.Generic;
using Multiplex.UI.Web.Tea.Helpers;
using Multiplex.Models.Security;

namespace Multiplex.UI.Web.Tea.Controllers
{
    [Authorize]
    public class AccountController : BaseController
    {
        #region Login

        [AllowAnonymous]
        public ActionResult Login(string returnUrl)
        {
            ViewBag.ReturnUrl = returnUrl;
            if (Request.IsAuthenticated)
            {
                return View("Unauthorised");
            }

            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        public ActionResult Login(UserInformation userInformation, string returnUrl)
        {
            userInformation.Error = string.Empty;
            var userManager = new UserManager();
            var login = userManager.Login<TeaDataContext, UserInformation>(userInformation);

            if (login.Item1 && login.Item2 != null)
            {
                if (login.Item2.PasswordChanged)
                {
                    FormsAuthentication.SetAuthCookie(userInformation.UserName, false);

                    if (userInformation.DateOfBirth.AddYears(13) > DateTime.Now && !User.IsInRole(Multiplex.Models.Tea.Constants.CLIENT))
                    {
                        var roleAssignment = new RoleAssignment();
                        roleAssignment.AssignUserRole(userInformation.UserName, Multiplex.Models.Tea.Constants.CLIENT);
                    }

                    if (!string.IsNullOrWhiteSpace(returnUrl))
                    {
                        return Redirect(returnUrl);
                    }

                    //return RedirectToAction("Index", "Browse");
                    return RedirectToAction("FeaturedBusiness", "BusinessProfile");
                }
                else
                {
                    return View("ChangeGeneratedPassword", userInformation);
                }
            }
            userInformation.Error = login.Item3;
            return View(userInformation);
        }

        #endregion Login

        #region Reset Password

        [AllowAnonymous]
        public ActionResult ResetPassword(string returnUrl)
        {
            ViewBag.ReturnUrl = returnUrl;
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        public ActionResult ResetPassword(UserInformation userInformation, string returnUrl)
        {
            userInformation.Error = string.Empty;
            userInformation.UserName = userInformation.Cellphone;
            ((UserInfo)userInformation).Cellphone = userInformation.Cellphone;

            var securityService = new PasswordManager();
            var resetPassword = securityService.ResetPassword<TeaDataContext, UserInformation>(userInformation);

            if (resetPassword.Item1)
            {
                return RedirectToAction("ResetPasswordSuccess", new { statusMessage = resetPassword.Item2 });
            }

            userInformation.Error = resetPassword.Item2;
            return View(userInformation);
        }

        [HttpPost]
        [AllowAnonymous]
        public JsonResult ResetPasswordModal(string cellphone)
        {
            var userInformation = new UserInformation();
            userInformation.Cellphone = cellphone;
            userInformation.Error = string.Empty;
            userInformation.UserName = userInformation.Cellphone;
            ((UserInfo)userInformation).Cellphone = userInformation.Cellphone;

            var securityService = new PasswordManager();
            var resetPassword = securityService.ResetPassword<TeaDataContext, UserInformation>(userInformation);

            return Json(resetPassword.Item2, JsonRequestBehavior.AllowGet);
        }

        [AllowAnonymous]
        public ActionResult ResetPasswordSuccess(string statusMessage)
        {
            return View((object)statusMessage);
        }

        #endregion Reset Password

        #region Profile

        public ActionResult Profile()
        {
            var securityService = new DomainService();
            var userInformation = securityService.GetEntity<TeaDataContext, UserInformation>(User.Identity.Name, null);

            if (userInformation == null)
            {
                return RedirectToAction("Index", "Home");
            }

            return View(userInformation);
        }

        public ActionResult ProfileByUsername(string username)
        {
            var securityService = new DomainService();
            var userInformation = securityService.GetEntity<TeaDataContext, UserInformation>(username, null);

            if (userInformation == null)
            {
                return RedirectToAction("Index", "Home");
            }

            return View("Profile", userInformation);
        }

        [HttpPost]
        public ActionResult Profile(UserInformation userInformation)
        {
            userInformation.Error = string.Empty;
            var securityService = new DomainService();

            userInformation = securityService.SaveEntity<TeaDataContext, UserInformation>(userInformation, UserId, null);

            if (userInformation == null)
            {
                return RedirectToAction("Index", "Home");
            }
            userInformation.Error = Multiplex.Models.Security.Constants.PROFILE_UPDATED;
            return View(userInformation);
        }

        #endregion Profile

        #region Change Password

        [Authorize]
        public ActionResult ChangePassword()
        {
            return View(UserInformation);
        }

        [AllowAnonymous]
        public ActionResult ChangeGeneratedPassword(UserInformation userInformation)
        {
            return View(userInformation);
        }

        [HttpPost]
        [AllowAnonymous]
        public ActionResult ChangeGeneratedPassword(UserInformation userInformation, string returnUrl)
        {
            userInformation.Error = string.Empty;

            var passwordManager = new PasswordManager();
            var changePassword = passwordManager.ChangePassword(userInformation);

            if (changePassword.Item1)
            {
                var service = new DomainService();

                userInformation = service.GetEntity<TeaDataContext, UserInformation>(userInformation.UserName, null);
                userInformation.PasswordChanged = true;
                service.SaveEntity<TeaDataContext, UserInformation>(userInformation, UserId, null);

                FormsAuthentication.SetAuthCookie(userInformation.UserName, false);

                if (!string.IsNullOrWhiteSpace(returnUrl))
                {
                    return Redirect(returnUrl);
                }

                return RedirectToAction("Index", "Home");
            }

            userInformation.Error = changePassword.Item2;
            return View(userInformation);
        }

        [HttpPost]
        [Authorize]
        public ActionResult ChangePassword(UserInformation userInformation)
        {
            userInformation.Error = string.Empty;
            userInformation.SetMembership(Membership.GetUser());

            var passwordManager = new PasswordManager();
            var changePassword = passwordManager.ChangePassword(userInformation);

            if (changePassword.Item1)
            {
                return RedirectToAction("Profile", "Account");
            }

            userInformation.Error = changePassword.Item2;
            return View(userInformation);
        }

        #endregion Change Password

        #region Log Off

        [Authorize]
        public ActionResult LogOff()
        {
            FormsAuthentication.SignOut();

            return RedirectToAction("Index", "Home");
        }

        #endregion Log Off

        #region Register

        [AllowAnonymous]
        public ActionResult Register(int clientId = 0)
        {
            var userInformation = new UserInformation();

            return View(userInformation);
        }

        [HttpPost]
        [AllowAnonymous]
        public ActionResult Register(UserInformation userInformation)
        {
            if ((DateTime.Today - userInformation.DateOfBirth).Days / 365.25 < 13)
            {
                userInformation.Error = "You have to be 13 years and older to register.";
                return View(userInformation);
            } 

            var userId = Request.IsAuthenticated ? UserId : Guid.Empty;
            //userInformation.Error = string.Empty;
            //userInformation.UserName = userInformation.Cellphone;

            //var userManager = new UserManager();
            //string[] roles = null;

            //if (userInformation.DateOfBirth.AddYears(13) < DateTime.Now)
            //{
            //    roles = new string[] { Multiplex.Models.Tea.Constants.CLIENT };
            //}
            //else
            //{
            //    roles = new string[] { Multiplex.Models.Tea.Constants.USER };
            //}

            ////((UserInfo)userInformation).Cellphone = userInformation.Cellphone;
            //var register = userManager.Register<TeaDataContext, UserInformation>(userInformation, userId, true, roles);
            var registerHelper = new RegisterHelper(userId, userInformation);
            registerHelper.Register();

            if (!registerHelper.Response.Item1)
            {
                userInformation.Error = registerHelper.Response.Item2;
                return View(userInformation);
            }

            return RedirectToAction("RegisterSuccess", new { statusMessage = registerHelper.Response.Item2 });
        }


        //[Authorize(Roles = Multiplex.Models.Tea.Constants.ROLE_ADMIN)]
        [AllowAnonymous]
        public ActionResult RegisterSuccess(string statusMessage)
        {
            return View((object)statusMessage);
        }

        #endregion Register

        #region Lock / Unlock User

        [Authorize(Roles = Multiplex.Models.Tea.Constants.ROLE_ADMIN)]
        public ActionResult LockUnlockUser(string username, bool isLocked)
        {
            var securityService = new UserManager();
            securityService.LockUnclockUser<TeaDataContext>(username, isLocked);

            return RedirectToAction("Users");
        }

        #endregion Lock / Unlock User

        [Authorize(Roles = Multiplex.Models.Tea.Constants.ROLE_ADMIN + ", " + Multiplex.Models.Tea.Constants.SUPER_ADMIN)]
        public ActionResult Users()
        {
            var securityService = new DomainService();
            var usersInformation = securityService.GetEntities<TeaDataContext, UserInformation>(null, null, null);

            if (!User.IsInRole(Multiplex.Models.Tea.Constants.SUPER_ADMIN))
            {
                usersInformation = usersInformation.Where(ui => !Roles.IsUserInRole(ui.UserName, Multiplex.Models.Tea.Constants.SUPER_ADMIN)).ToList();
            }

            return View(new Tuple<List<UserInformation>, bool>(usersInformation, false));
        }

        [Authorize(Roles = Multiplex.Models.Tea.Constants.ROLE_ADMIN)]
        [HttpPost]
        public ActionResult Users(FormCollection formCollection)
        {
            var securityService = new DomainService();
            var usersInformation = securityService.GetEntities<TeaDataContext, UserInformation>(formCollection["usernameSearch"], formCollection["emailSearch"], null);

            return View(new Tuple<List<UserInformation>, bool>(usersInformation, true));
        }

        [Authorize(Roles = Multiplex.Models.Tea.Constants.ROLE_ADMIN + ", " + Multiplex.Models.Tea.Constants.SUPER_ADMIN)]
        public ActionResult UserRoles(string username)
        {
            var userRoleRetrieval = new UserRoleRetrieval();
            var userInRoles = userRoleRetrieval.GetUserRoles(username);

            if (!User.IsInRole(Multiplex.Models.Tea.Constants.SUPER_ADMIN))
            {
                userInRoles.UserRoles = userInRoles.UserRoles.Where(ur => ur.RoleName != Multiplex.Models.Tea.Constants.SUPER_ADMIN).ToList();
            }

            return View(userInRoles);
        }

        [Authorize(Roles = Multiplex.Models.Tea.Constants.ROLE_ADMIN)]
        [HttpPost]
        public ActionResult UserRoles(FormCollection formCollection)
        {
            var username = formCollection["Username"];
            var formUserInRoles = ConvertFormCollection();

            if (!string.IsNullOrWhiteSpace(username) && formUserInRoles != null)
            {
                var userRoleUpdate = new UserRoleUpdate();

                userRoleUpdate.UpdateUserRoles(username, formUserInRoles);
            }

            return RedirectToAction("UserRoles", new { username = username });
        }

        [Authorize(Roles = Multiplex.Models.Tea.Constants.ROLE_ADMIN)]
        [HttpPost]
        public ActionResult GetRoles(FormCollection formCollection)
        {
            var roleName = formCollection["roleName"];
            var statusMessage = string.Format(Multiplex.Models.Security.Constants.ROLECREATION_FAILED, roleName);

            if (!string.IsNullOrWhiteSpace(roleName))
            {
                Roles.CreateRole(roleName);
                statusMessage = string.Format(Multiplex.Models.Security.Constants.ROLECREATION_PASSED, roleName);
            }
            else
            {
                statusMessage = "Role required.";
            }

            return RedirectToAction("GetRoles", new { createRole = roleName, statusMessage = statusMessage });
        }

        [Authorize(Roles = Multiplex.Models.Tea.Constants.ROLE_ADMIN)]
        public ActionResult DeleteRole(string rolename)
        {
            Roles.DeleteRole(rolename);

            return RedirectToAction("GetRoles");
        }
    }
}