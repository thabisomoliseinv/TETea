﻿using Multiplex.DomainServices.Communication;
using Multiplex.Models.Communication;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Multiplex.UI.Web.Tea.Controllers
{
    public class ContactController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(FormCollection formCollection, string submit)
        {
            var result = View();

            if (Request["submit"] != null)
            {
                var name = formCollection["Name"] != null ? formCollection["Name"] : string.Empty;
                var from = formCollection["Email"] != null ? formCollection["Email"] : string.Empty;
                var to = ConfigurationManager.AppSettings["MailTo"] != null ? ConfigurationManager.AppSettings["MailTo"] : string.Empty;
                var subject = formCollection["Subject"] != null ? formCollection["Subject"] : string.Empty;
                var message = formCollection["Message"] != null ? formCollection["Message"] : string.Empty;
                var communicationDomainSevice = new DomainService();
                var sendStatus = communicationDomainSevice.SendMail("",from, to, string.Empty, string.Empty, subject + ": " + name, message, string.Empty);
                var contact = new Contact();

                if (sendStatus == "Success")
                {
                    contact.SendStatus = "Message submitted successfully.";
                }
                else
                {
                    contact.Name = name;
                    contact.Email = from;
                    contact.Subject = subject;
                    contact.Message = message;
                    contact.SendStatus = sendStatus;
                }

                result = View(contact);
            }

            return result;
        }
    }
}