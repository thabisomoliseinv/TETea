﻿using Multiplex.DomainServices.Tea;
using Multiplex.Models.Tea;
using Multiplex.UI.Web.Tea.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Multiplex.UI.Web.Tea.Controllers
{
    public class RecommendationController : BaseController
    {
        [AllowAnonymous]
        public ActionResult Index()
        {
            var service = new DomainService<BusinessProfile>();
            var businessProfiles = service.GetEntities(bp => bp.Active, new string[] { "UserInformation", "Category" });

            return View("Index", businessProfiles);
        }

        [Authorize]
        public JsonResult Like(int businessProfileId)
        {
            var service = new DomainService<BusinessProfileLike>();
            var businessProfileLike = new BusinessProfileLike();
            businessProfileLike.UserInformationId = UserInformation.Id;
            businessProfileLike.BusinessProfileId = businessProfileId;
            businessProfileLike = service.SaveEntity(businessProfileLike, UserId, new string[] { "UserInformation" });
            var businessProfileRecommendations = service.GetEntities(bpr => bpr.BusinessProfileId == businessProfileId, null);

            if (FeaturedHelper.BusinessProfile != null && FeaturedHelper.BusinessProfile.Id == businessProfileId)
            {
                if (FeaturedHelper.BusinessProfile.BusinessProfileRecommendations == null)
                {
                    FeaturedHelper.BusinessProfile.BusinessProfileRecommendations = new List<BusinessProfileRecommendation>();
                }

                FeaturedHelper.BusinessProfile.BusinessProfileLikes.Add(businessProfileLike);
            }

            return Json(businessProfileRecommendations.Count, JsonRequestBehavior.AllowGet);
        }

        [Authorize]
        public JsonResult Unlike(int businessProfileId)
        {
            var count = 0;
            var service = new DomainService<BusinessProfileLike>();
            var businessProfileLikes = service.GetEntities(bpl => bpl.BusinessProfileId == businessProfileId, null);

            if (businessProfileLikes != null)
            {
                var businessProfileLike = service.GetEntity(bpl => bpl.BusinessProfileId == businessProfileId && bpl.UserInformationId == UserInformation.Id, null);

                if (businessProfileLike != null)
                {
                    service.DeleteEntity(businessProfileLike.Id);
                    count = businessProfileLikes.Count - 1;

                    if (FeaturedHelper.BusinessProfile != null && FeaturedHelper.BusinessProfile.Id == businessProfileId)
                    {                        
                        FeaturedHelper.BusinessProfile.BusinessProfileLikes = FeaturedHelper.BusinessProfile.BusinessProfileLikes.Where(bfl => bfl.BusinessProfileId != businessProfileId).ToList();
                    }
                }
            }

            return Json(count, JsonRequestBehavior.AllowGet);
        }

        [Authorize]
        public JsonResult Recommend(int businessProfileId, string comment)
        {
            var service = new DomainService<BusinessProfileRecommendation>();
            var businessProfileRecommendation = new BusinessProfileRecommendation();
            businessProfileRecommendation.UserInformationId = UserInformation.Id;
            businessProfileRecommendation.BusinessProfileId = businessProfileId;
            businessProfileRecommendation.Comment = comment;
            businessProfileRecommendation.Active = false;
            businessProfileRecommendation = service.SaveEntity(businessProfileRecommendation, UserId, new string[] { "UserInformation" });
            var businessProfileRecommendations = service.GetEntities(bpr => bpr.BusinessProfileId == businessProfileId, null);

            if (FeaturedHelper.BusinessProfile != null && FeaturedHelper.BusinessProfile.Id == businessProfileId)
            {
                if (FeaturedHelper.BusinessProfile.BusinessProfileRecommendations == null)
                {
                    FeaturedHelper.BusinessProfile.BusinessProfileRecommendations = new List<BusinessProfileRecommendation>();
                }

                FeaturedHelper.BusinessProfile.BusinessProfileRecommendations.Add(businessProfileRecommendation);
            }

            var recommendationNotifier = new RecommendationNotifier(businessProfileRecommendation);
            recommendationNotifier.Notify();

            return Json(businessProfileRecommendations.Count, JsonRequestBehavior.AllowGet);
        }

        [Authorize(Roles = Multiplex.Models.Tea.Constants.CLIENT)]
        public ActionResult ViewComment(int id)
        {
            var service = new DomainService<BusinessProfileRecommendation>();
            var businessProfileRecommendation = service.GetEntity(bpr => bpr.Id == id && bpr.BusinessProfile.UserInformationId == UserInformation.Id, new string[] { "BusinessProfile", "UserInformation" });

            return View(businessProfileRecommendation);
        }

        [Authorize(Roles = Multiplex.Models.Tea.Constants.CLIENT)]
        [HttpPost]
        public ActionResult ViewComment(BusinessProfileRecommendation businessProfileRecommendation)
        {
            var service = new DomainService<BusinessProfileRecommendation>();

            businessProfileRecommendation.Active = !businessProfileRecommendation.Active;
            service.SaveEntity(businessProfileRecommendation, UserId, new string[] { "BusinessProfile", "UserInformation" });

            return RedirectToAction("ViewComment", new { id = businessProfileRecommendation.Id });
        }

        [Authorize]
        public ActionResult LikedBusinesses()
        {
            var service = new DomainService<BusinessProfileLike>();
            var businessProfileLikes = service.GetEntities(c => c.UserInformationId == UserInformation.Id, new string[] { "BusinessProfile" });

            return View(businessProfileLikes);
        }

        [Authorize]
        public JsonResult Conversate(int businessProfileRecommendationId, string comment)
        {
            var commentConversation = new CommentConversation();
            commentConversation.BusinessProfileRecommendationId = businessProfileRecommendationId;
            commentConversation.UserInformationId = UserInformation.Id;
            commentConversation.Comment = comment;

            var service = new DomainService<CommentConversation>();
            service.SaveEntity(commentConversation, UserId, null);
            var jsonResult = string.Format("{{Name: {0} {1}, Comment: {2}}}", UserInformation.FirstName, UserInformation.Surname, comment);

            return Json(jsonResult, JsonRequestBehavior.AllowGet);
        }
    }
}