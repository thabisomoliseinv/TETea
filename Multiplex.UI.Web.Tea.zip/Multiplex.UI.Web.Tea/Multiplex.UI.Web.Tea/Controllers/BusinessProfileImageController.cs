﻿using Multiplex.DomainServices.Tea;
using Multiplex.Models.Tea;
using Multiplex.Utilities.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Multiplex.UI.Web.Tea.Controllers
{
    public class BusinessProfileImageController : Controller
    {
        [AllowAnonymous]
        public ActionResult GetImage(int businessProfileImageId)
        {
            var service = new DomainService<BusinessProfileImage>();
            var businessProfileImage = service.GetEntity(c => c.Id == businessProfileImageId, null);

            if (businessProfileImage != null && businessProfileImage.Image != null && businessProfileImage.Image.Length > 0)
            {
                return File(businessProfileImage.Image, "image/png");
            }

            var path = string.Format("{0}{1}", Request.PhysicalApplicationPath, ConfigurationReader.GetAppSetting("DefaultImage"));
            return File(path, "image/png");
        }
    }
}