﻿$(function () {
    $(document).ready(function () {
        //$("#grid").dataTable().fnDestroy();

        //$('.grid').dataTable({
        //    "bDestroy": true
        //}).fnDestroy();

        //$.each($('.grid'),function (i,value) {
        //    $(this).dataTable().fnDestroy();
        //    $(this).DataTable();
        //});
    });
}(jQuery));